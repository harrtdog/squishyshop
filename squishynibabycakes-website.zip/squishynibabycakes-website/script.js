// Squishynibabycakes — cart and mobile navigation demo
const cart = [];

const cartCount = document.getElementById("cart-count");
const cartItems = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");
const cartMessage = document.getElementById("cart-message");
const inquiryButton = document.getElementById("inquiry-button");
const menuToggle = document.getElementById("menu-toggle");
const navLinks = document.getElementById("nav-links");

function formatPeso(amount) {
  return "₱" + amount.toLocaleString("en-PH");
}

function renderCart() {
  cartCount.textContent = cart.length;

  if (cart.length === 0) {
    cartItems.innerHTML = '<p class="empty-cart">Your cart is empty. Add a squishy you love! ♡</p>';
  } else {
    cartItems.innerHTML = "";
    cart.forEach((item, index) => {
      const row = document.createElement("div");
      row.className = "cart-item";

      const details = document.createElement("div");
      const name = document.createElement("div");
      name.className = "cart-item-name";
      name.textContent = item.name;
      const price = document.createElement("div");
      price.textContent = formatPeso(item.price);
      details.append(name, price);

      const removeButton = document.createElement("button");
      removeButton.className = "remove-item";
      removeButton.type = "button";
      removeButton.textContent = "Remove";
      removeButton.setAttribute("aria-label", "Remove " + item.name + " from cart");
      removeButton.addEventListener("click", () => {
        cart.splice(index, 1);
        renderCart();
        cartMessage.textContent = "Item removed from your demo cart.";
      });

      row.append(details, removeButton);
      cartItems.appendChild(row);
    });
  }

  const total = cart.reduce((sum, item) => sum + item.price, 0);
  cartTotal.textContent = formatPeso(total);
}

document.querySelectorAll(".add-to-cart").forEach((button) => {
  button.addEventListener("click", () => {
    cart.push({
      name: button.dataset.name,
      price: Number(button.dataset.price)
    });
    renderCart();
    cartMessage.textContent = button.dataset.name + " added to your demo cart!";
  });
});

inquiryButton.addEventListener("click", () => {
  if (cart.length === 0) {
    cartMessage.textContent = "Please add a product to your cart first. ♡";
    return;
  }

  const orderLines = cart.map(item => `${item.name} — ${formatPeso(item.price)}`);
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  cartMessage.textContent =
    "Your inquiry summary: " + orderLines.join(" • ") +
    ". Estimated total: " + formatPeso(total) +
    ". This is a demo only; no order has been sent and no payment was collected. Please contact the shop to confirm availability, delivery fees, and payment.";
});

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
    menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();
renderCart();
