# Squishynibabycakes Website

A responsive pastel-pink website concept for Squishynibabycakes, a squishy-toy marketplace supporting Filipino small businesses and local creators.

## Files

- `index.html` — website content and sections
- `style.css` — layout, colors, responsive design, and animations
- `script.js` — demo shopping cart and mobile navigation

## Run locally

1. Download or extract the project folder.
2. Open `index.html` in a browser.

No build tools are required. The Google Font is optional; the website uses fallback fonts if it cannot load.

## Publish with GitHub Pages

1. Create a GitHub repository, for example `squishynibabycakes`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open the repository's **Settings**.
4. Select **Pages** from the sidebar.
5. Under **Build and deployment**, select **Deploy from a branch**.
6. Choose the `main` branch and `/ (root)` folder, then save.
7. Wait for GitHub Pages to publish the site. The Pages section will show the published URL.

## Customize before publishing

- Change the sample products and prices in `index.html`.
- Replace `yourbusiness@email.com` and the sample social details with your official contact information.
- The cart is a front-end demo only. It does not send orders, process payments, or save customer information.
- The Privacy Policy is a starter notice for a school/demo project. Update it to match your actual practices and applicable legal requirements before collecting real customer data.

## Slogan

**Squish Your Stress, Support Local!**
